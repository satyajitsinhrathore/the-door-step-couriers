<?php 

$server = "localhost";
$username = "root";
$password = "";
$database = "cms_db";

// $conn= mysqli_connect('localhost','root','','cms_db')or die("Could not connect to mysql".mysqli_error($con));

$conn= mysqli_connect($server, $username, $password, $database);
if ($conn){
    // echo "success";
    // die("Error". mysqli_connect_error());

}
else {
    die("Error". mysqli_connect_error());

}

?>